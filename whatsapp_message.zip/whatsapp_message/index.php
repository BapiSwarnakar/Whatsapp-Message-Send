<!DOCTYPE html>
<html>
<head>
	<title>Whatsapp Message Sending System</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script>


	<link rel="stylesheet" href="font-awesome/font-awesome-4.7.0/css/font-awesome.min.css">

</head>
<body>
<div class="container mt-5">
	<h1>Whatsapp Sending Sms</h1>
	<a href="https://wa.me/919614445565?text=hello" target="_blank"><i class="fa fa-whatsapp fa-2x bg-light fa-spin" style="color: green;" aria-hidden="true"></i>
</a>
</div>
</body>
</html>